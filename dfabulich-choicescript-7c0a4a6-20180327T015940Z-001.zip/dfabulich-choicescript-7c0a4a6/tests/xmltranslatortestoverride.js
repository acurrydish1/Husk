function xmlTranslatorTestOverride() {}
